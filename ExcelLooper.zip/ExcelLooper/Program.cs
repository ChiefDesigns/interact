﻿using CsvHelper;
using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace ExcelLooper
{
    class Program
    {
        static void Main(string[] args)
        {
            string filesFolderInput;
            string destFolderInput;
            Console.Write("Enter the files folder: ");
            filesFolderInput = Console.ReadLine();

            Console.Write("Enter the destination folder: ");
            destFolderInput = Console.ReadLine();

            if (filesFolderInput != null && destFolderInput != null)
            {
                try
                {
                    var path = @$"{filesFolderInput}";
                    var destPath = @$"{destFolderInput}\merged.csv";
                    var files = Directory.EnumerateFiles(path, "*.csv");
                    var dictionary = new Dictionary<string, string>();
                    var destFile = new StreamWriter(destPath, true);
                    var config = SetCsvConfig();
                    var stopwatch = new Stopwatch();

                    stopwatch.Start();
                    Console.WriteLine("Beginning data reading....");
                    foreach (var f in files)
                    {
                        ReadFile(f, config, dictionary);
                    }

                    // Write the desired header for the output file.
                    destFile.WriteLine("ID, Property_1, Property_2, Property_3, Property_3, Property_4, Property_5, Property_6, Property_7");

                    foreach (KeyValuePair<string, string> kvp in dictionary)
                    {
                        var split = kvp.Value.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                        var row = kvp.Key + "," + String.Join(',', split);

                        destFile.WriteLine(row);
                    }

                    destFile.Close();
                    stopwatch.Stop();

                    CalculateEllapsedTime(stopwatch);

                } catch(Exception e)
                {
                    Console.WriteLine("Aborting! An error has occurred.");
                    // Gracefull handle exceptions here...
                }
            }
        }

        private static CsvConfiguration SetCsvConfig()
        {
            return new CsvConfiguration(CultureInfo.CurrentCulture) 
            {
                Delimiter = ",",
                Encoding = Encoding.UTF8,
                HeaderValidated = null,
                MissingFieldFound = null

            };
        }

        private static void ReadFile(string f, CsvConfiguration config, Dictionary<string, string> dictionary)
        {
            using (var reader = new StreamReader(f))
            using (var csv = new CsvReader(reader, config))
            {
                var records = csv.GetRecords<CSVMapperEnity>();

                foreach (var r in records)
                {
                    if (dictionary.ContainsKey(r.ID))
                    {
                        // Append another row to the string value of existing ID
                        // This is hacky, there may be better ways...
                        dictionary[r.ID] += r.ConcatRowValues();
                    }
                    else if (!dictionary.ContainsKey(r.ID))
                    {
                        // Add the ID to the dictionary if it doesn't exist
                        var value = r.ConcatRowValues();
                        dictionary.Add(r.ID, value);
                    }
                }
            }
        }

        private static void CalculateEllapsedTime(Stopwatch stopwatch)
        {
            var elapsedMs = stopwatch.ElapsedMilliseconds;
            TimeSpan t = TimeSpan.FromMilliseconds(elapsedMs);
            string ellapsedTimeOutput = string.Format("{0:D2}h:{1:D2}m:{2:D2}s:{3:D3}ms", t.Hours, t.Minutes, t.Seconds, t.Milliseconds);

            Console.WriteLine("All done, ellapsed time: " + ellapsedTimeOutput);
        }
    }
}
