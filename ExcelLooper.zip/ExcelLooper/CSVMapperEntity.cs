﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelLooper
{
    public class CSVMapperEnity
    {
        [Name("ID")]
        public string ID { get; set; }
        [Name("Property_1")]
        public string Property_1 { get; set; }
        [Name("Property_2")]
        public string Property_2 { get; set; }
        [Name("Property_3")]
        public string Property_3 { get; set; }
        [Name("Property_4")]
        public string Property_4 { get; set; }
        [Name("Property_5")]
        public string Property_5 { get; set; }
        [Name("Property_6")]
        public string Property_6 { get; set; }
        [Name("Property_7")]
        public string Property_7 { get; set; }

        public string ConcatRowValues()
        {
            return $"{Property_1},{Property_2},{Property_3},{Property_4},{Property_5},{Property_6},{Property_7}";
        }
    }
}
