# InteractTechTest

This project was generated with c# .net core 5

A simple console application for merging row values based on a unique identifier.

## Excel Looper

Use visual studio to install dependencies and run the application.
Alternatively, 

## Data Files

One of the data files was a missing an Id as well as the value.
A dummy value was used in place for both sets of data.
Alternatively, a practice can be put in place for missing headers and values.

## CSV Library

Making full use of library features would have simplified the task, especially when merging the rows.

## Duration To Complete Task

It took me roughly about 5-6 hours to achieve what I believe is the correct outcome.
I had to do a bit of background reading on some topics

## Output files

merged-dev csv file has been added as a result of merging.
The live version is too big to add as part of the zipped file



